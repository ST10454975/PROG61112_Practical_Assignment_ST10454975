class Product {
    //declaring attributes of product
    private String name;
    private int quantity;
    private double price;
//constructor for product (used auto gen feature provided by intellij
    public Product(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }
// getters and setters also used auto gen feature provided by intellij
    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //method ot display the report of the products
    public void displayProduct() {
        System.out.println("Name: " + name + ", Quantity: " + quantity + ", Price: $" + price);
    }
}

class Inventory {
    //array of objects (Product) named products

    private Product[] products;
    //placeholder var to be used to help keep track of number of items in array
    private int count;

    //method that takes in an argument to determine how many products can be stored in the inventory


    public Inventory(int size) {
        //making product array to hold number of products of size "size"
        products = new Product[size];
        //no preexisting products therefore count is set to 0
        count = 0;
    }

    //method takes in an object as an argument
    public void addProduct(Product product) {
        //if state to check if count is less than length of products array
        //if so, therefore there is still space and the new product will be added in at
        // product[index count]
        if (count < products.length) {
            products[count] = product;
            count++;
        } else {
            System.out.println("Inventory is full!");
        }
    }
    //method that takes in 2 arguments
    public void updateQuantity(String name, int quantity) {
        //for loop ot loop through products array
        for (int i = 0; i < count; i++) {
            //if state to check if the item at products index i is equal to the name given in the argument

            if (products[i].getName().equals(name)) {
                //if it is equal the quantity wil be set to the quantity given in the argument
                products[i].setQuantity(quantity);
                // after we will break out of the loop once condition are met
                break;
            }
        }
    }
    //method to display inventory
    public void displayInventory() {
        //for loop to loop through products array
        for (int i = 0; i < count; i++) {
            //starting form index i = 0 (first element to the last element = count
            //every element will be displayed
            products[i].displayProduct();
        }
    }
    //method to gen report
    public void generateReport() {
        //this method will call the display inventory method explained above
        System.out.println("Inventory Report:");
        displayInventory();
    }
}