//brief idea of the problem
//The small business owner needs to manage their inventory does not have capital to pay accountant to help stock control
// and would rather have a simple program that allows him to do this manually .
// They just want to keep track of the products, their quantities, and prices. they are not concerned about stock control  princples as they
// they dont hold much stock and their stock turn over is high
// The system will allow the owner to add, update, and view products.
// the owner should be able to generate a report showing all products in stock



public class Main {
    public static void main(String[] args) {
        //new inverntory object so that we can use its methods
        Inventory inventory = new Inventory(10);
        //adding products to the inventory
        inventory.addProduct(new Product("Laptop", 5, 999.99));
        inventory.addProduct(new Product("Smartphone", 10, 499.99));

        inventory.displayInventory();

        inventory.updateQuantity("Laptop", 8);

        inventory.generateReport();
    }
}