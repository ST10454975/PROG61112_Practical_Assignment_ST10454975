import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class ProductTest {

    public ProductTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getName method, of class Product.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Product instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getQuantity method, of class Product.
     */
    @Test
    public void testGetQuantity() {
        System.out.println("getQuantity");
        Product instance = null;
        int expResult = 0;
        int result = instance.getQuantity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setQuantity method, of class Product.
     */
    @Test
    //format auto gen using net beans feature
    public void testSetQuantity() {
        System.out.println("setQuantity");
        //set quantity to 7
        int quantity = 7;
        //instance of a product object that is named instance
        Product instance = new Product("apple",quantity,14.56); ;
        //setting quan to var above
        instance.setQuantity(quantity);
        //new product object ot test
        //Product testSetQuan =
        //if the expected result is the same as the testSetquan quantity. therefore pass
        double expResult = 7;
        double Result = instance.getQuantity();
        assertEquals(expResult,Result,0);

        }
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");


    /**
     * Test of getPrice method, of class Product.
     */
    @Test
    public void testGetPrice() {
        System.out.println("getPrice");
        Product instance = new Product("apple",14,14.99);
        double expResult = 14.99;
        double result = instance.getPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPrice method, of class Product.
     */
    @Test
    public void testSetPrice() {
        System.out.println("setPrice");
        //Product testProductPrice =
        double price = 18.99;
        Product instance = new Product("apple",7,18.99);;
        instance.setPrice(price);
        double expResult = 18.99;
        double result = instance.getPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of displayProduct method, of class Product.
     */
    @Test
    public void testDisplayProduct() {
        System.out.println("displayProduct");
        Product instance = new Product("apple",7,15.98);
        instance.displayProduct();
        //idk how i would test a sting out put
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

}
